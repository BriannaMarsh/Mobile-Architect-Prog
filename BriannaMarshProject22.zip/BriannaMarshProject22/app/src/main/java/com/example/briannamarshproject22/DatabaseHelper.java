package com.example.briannamarshproject22;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    //setting the stage for my table
    static final String SQLLite_database = "EventPlanner.DB";
    static final int databaseVersion = 1;

    static final String database_Table = "Events of The Month"; //methods for the database
    static final String dates = "Dates of the week";
    static final String events = "Events of the week";
    static final String length = "Length of events";
    static final String create = "Create/Add an event";
    static final String change = "Delete or Update an event";


    private static final String Create_DB_Query = "Create Yor Table" + database_Table + " ( " + dates +
            events + length + create + change + " ) "; // creating the columns of the table


    public DatabaseHelper(Context context) {
        super(context, SQLLite_database, null, databaseversion);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        db.execSQL(Create_DB_Query); // creating the table
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP Table if Exists" + database_Table); //database completed
    }
}
