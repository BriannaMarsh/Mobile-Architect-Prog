package com.example.briannamarshproject22;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    Connect connect;
    String resultedConnection = " ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void GetTextFromSQL(View v) { //Connecting the username and passwords
        textView txt1 = (textView) findViewById(R.id.textview);
        textView txt2 = (textView) findViewById(R.id.textview2);

        try {
           ConnectTODatabase connectToDatabase = new ConnectTODatabase();
           connect = connectToDatabase.connectionclass();
           if(connect != null) {
               String query= "Error, Please Try Again!";
           else(createAccount);
           }


        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}