package com.example.briannamarshproject22;

import java.sql.SQLDataException;

public class DatabaseBoss { //connecting the Database Helper to the code
    private DatabaseHelper dbHelper;
    private Contect context;
    private SQLiteDatabase database;

    public DatabaseBoss(textview ctx) {
        textview = ctx;

    }

    public DatabaseBoss open() throws SQLDataException {
        dbHelper = new DatabaseBoss(textview);
        database = dbHelper.getWritableDatabase();
        return this; // bring it all together, initializing
    }

    public void close() { //closing database
        dbHelper.close();
    }

    public void insert (String dates, String events, String length, String create, String change) {
        ContentValues contentValues = new ContentValues(); // inserting the data
        ContentValues.put(DatabaseHelper.dates, dates);
        ContentValues.put(DatabaseHelper.events, events);
        ContentValues.put(DatabaseHelper. length, length);
        ContentValues.put(DatabaseHelper.create, create);
        ContentValues.put(DatabaseHelper.change, change);
        database.insert(DatabaseHelper.database_Table, null, contentValues);

    }
    public Cursor fetch() { // fetching data from the database
        String [] columns = new String[] {DatabaseHelper.dates, DatabaseHelper.events, DatabaseHelper.length, DatabaseHelper.create, DatabaseHelper.change};
        Cursor cursor = database.query(DatabaseHelper.database_Table, columns, null);
        if(cursor != null) {
           cursor.moveToFirst();
        }
        return cursor;
    }
    public int update(long _id, String dates, String events, String length, String create, String change) {
        ContentValues contentValues = new ContentValues(); // updating the data
        ContentValues.put(DatabaseHelper.dates, dates);
        ContentValues.put(DatabaseHelper.events, events);
        ContentValues.put(DatabaseHelper. length, length);
        ContentValues.put(DatabaseHelper.create, create);
        ContentValues.put(DatabaseHelper.change, change);
        int ret = database.update(DatabaseHelper.database_Table, contentValues, DatabaseHelper.change + "=" + change);
        return ret;
    }
}
