package com.example.briannamarshproject22;

import java.sql.Connection;

public class ConnectTODatabase { // setting the strings
    Connection com;
    String username;
    String password;
    String createAccount;

    public Connection connectionClass() { //Valid username and password
        username = "Asta";
        password = "IloveYoU4";
        createAccount = " ";
        Connection connection = null;

        return null;
    }
}
